#!/bin/bash
if [ "$1" = "-help" ]; then
echo "Uso: backup_full.sh ORIGEN DESTINO"
exit 0
fi
if [ $# -ne 2 ]; then
echo "Error: debe indicar origen y destino"
exit 1
fi
ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
if [ ! -d "$ORIGEN" ]; then
	echo "Error: el origen no existe"
	exit 1
fi

if ! mountpoint -q "$DESTINO"; then
	echo "Error: el destino no esta montado"
	exit 1
fi

if tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"; then
	echo "Backup generado correctamente"
else
	echo "Error al generar el backup"
	exit 1
fi
