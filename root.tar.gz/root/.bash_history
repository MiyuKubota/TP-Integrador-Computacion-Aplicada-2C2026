history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostname
cat /etc/hostname
cat /etc/debian_version
ping 8.8.8.8
ping google.com
cp /etc/apt/source.list /etc/apt/source.list.bak
nano /etc/apt/source.list
cp /etc/apt/sources.list /etc/apt/sources.list.bak
vi /etc/apt/sources.list
apt-get update
vi /etc/apt/sources.list
apt-get update
apt-get updagrade -y
apt-get upgrade -y
lsblk
grub-install /dev/sda
update-grub
dpkg --configure -a
apt-get full-upgrade -y
apt-get autoremove -y
reboot
exit
cat /etc/debian_version
apt-get install opensh-sever -y
apt-get install openssh-server -y
systemctl status ssh
systemctl enable ssh
systemctl is-enabled ssh
ls -l /root
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls -l /root
mkdir -p /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
chown -R root:root /root.ssh
chown -R root:root /root/.ssh
ls -l /root/.ssh
vi /etc/ssh/sshd_config
systemctl resrtart ssh
systemctl restart ssh
systemctl status ssh
chmod 600 /root/Material_Adicional_TPVMCA/clave_privda.txt
ls -l /root/Material_Adicional_TPVMCA
chmod 600 /root/Material_Adicional_TPVMCA/clave_privada.txt
ssh -i /root/Material_Adicional_TPVMCA/clave_privada.txt root@localhost
apt-get install apache2 php libapache2-mod-php php-mysql -y
systemctl status apache2
systemctl enable apache2
systemctl is-enabled apache2
php -v
apt-get install mariadb-server -y
systemctl status mariadb
systemctl enable mariadb
systemctl is-enabled mariadb
ls -l /root/Material_Adicional_TPVMCA/db.sql
mysql < /root/Material_Adicional_TPVMCA/db.sql
mysql -e "SHOW DATABASES;"
ip a
ip route
poweroff
vi /etc/network/interfaces
systemctl restart networking
ip a
ping 192.168.0.1
ping google.com
poweroff
lsblk
fdisk /dev/sdc
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
blkid
vi /etc/fstab
mount -a
vi /etc/fstab
systemctl daemon-reload
mount -a
df -h
cp /root/Material_Adicional_TPVMC/logo.png /www_dir/
cp /root/Material:Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adiconal_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/index.php /www_dor/
cp /root/Material_Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls -l /www_dir
vi /etc/apache2/sities-avaible/000-default.conf
vi /etc/apache2/sities-available/000-default.conf
vi /etc/apache2/sites-available/000-default.conf
vi /etc/apache2/apache2.conf
systemctl restart apache2
systemctl status apache2
apache2ctl configtest
cat /proc/partitions > /opt/particion
cat /opt/particion
df -h
ls -l /www_dir
poweroff
df -h
ls -l /www_dir
mkdir -p /opt/scripts
vi /opt/scripts/backup_full.sh
cat > /opt/scripts/backup_full.sh
rm /opt/scripts/backup_full.sh
cat > /opt/scripts/backup_full.sh
cat -n /opt/scripts/backup_full.sh
bash -n /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full-sh -help
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -lh /backup_dir
crontab -e
crontab -l
ls -l /opt/scripts/backup_full.sh
crontab -l
mkdir -p /tmp/entregables
tar -czf /tmp/entregables/root/.tar.gz /root
tar -czf /tmp/entregables/root.tar.gz /root
ls -lh /tmp/entregables
tar -czf /tmp/entregables/etc.tar.gz /etc
tar -czf /tmp/entregables/opt.tar.gz /opt
tar -czf /tmp/entregables/www_dir.tar.gz /www_dir
tar -czf /tmp/entregables/backup_dir.tar.gz /backup_dir
ls -lh /tmp/entregables
tar -czf /tmp/entregables/var.tar.gz /var
ls -lh /tmp/entregables/var.tar.gz
split -b 90M /tmp/entregables/var.tar.gz /tmp/entregables/var.tar.gz.part-
ls -lh /tmp/entregables
ls -lh /tmp/entregables
du -h /tmp/entregables/*
systemctl status ssh
cd /tmp/entregables
pwd
python3 -m http.server 8000 --bind 0.0.0.0
poweroff
whoami
pwd
ls
ls -l
whoami
whoami
pwd
cd /var/log
pwd
cd /etc/os-release
pwd
cd /var
pwd
ip a
pwd
pwd
cd /root
ls
ls -a
ls -l
cd Material_Adicional_TPVMCA
pwd
ls -l
ls
ip a
cd /etc
pwd
ls -l
cat os-release
systemctl status ssh
history
clear
man cp
poweroff
hostname
lsbk
lsblk
ls /www_dir
ip route
systemctl status ssh
awhomi
whomi
whoami
exit
exit
poweroff
hostname
cat /etc/os-release
systemctl is-active ssh apache2 mariadb cron
php -v
grep DocumentRoot /etc/apache2/sites-avaible/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
ls -l /www_dir
curl -I http://localhost
ip -br a
cat /etc/network/interfaces
ipconfig
ipconfig
mariadb -e "SHOW DATABASES;"
mariadb -e "SHOW tables from INGENIERIA;"
mariadb -e "SHOW tables from INGENIERIA;";"
mariadb -e "SHOW TABLES FROM ingenieria;"
mariadb -e "SHOW TABLES FROM ingenieria;"
sshd -Y | grep -E '^(permitrootlogin|pubkeyauthentication)'
sshd -T | grep -E '^(permitrootlogin|pubkeyauthentication)'
ls -la /root/.ssh
ls -la /root
ls -la /root/Material_Adicional_TPVMCA
sssh-keygen -lf /root/.ssh/authorized_keys
ssh-keygen -lf /root/.ssh/authorized_keys
ssh-keygen -lf /root/Material_adicional:TPVMCA/clave_publica.pub
ssh-keygen -lf /root/.ssh/authorized_keys
ssh-keygen -lf /root/Material_adicional:TPVMCA/clave_publica.pub
ssh-keygen -lf /root/Material*/clave_publica.pub
poweroff
